package com.example.naunem.sqlitedemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by naunem on 14/01/2017.
 */

public class DataSQLite extends SQLiteOpenHelper {
    private static String database_name = "toeic test2";
    private static int version = 2;
    private static String table_name = "reading";
    private static String table_name1 = "listening";

    public DataSQLite(Context context) {
        super(context, database_name, null, version);
    }

    private static final String create_table_reading = "CREATE TABLE IF NOT EXISTS " + table_name + " (" + Question._ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, question TEXT NOT NULL, a TEXT NOT NULL, b TEXT NOT NULL, c TEXT NOT NULL, d TEXT NOT NULL, answer TEXT NOT NULL)";
    private static final String create_table_listening = "CREATE TABLE IF NOT EXISTS " + table_name1 + " (" + Question._ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, question TEXT NOT NULL, a TEXT NOT NULL, b TEXT NOT NULL, c TEXT NOT NULL, d TEXT NOT NULL, answer TEXT NOT NULL)";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(create_table_reading);
        db.execSQL(create_table_listening);
    }
    private static final String drop_table = "DROP TABLE IF EXISTS " + table_name;
    private static final String drop_table1 = "DROP TABLE IF EXISTS " + table_name1;
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(drop_table);
        db.execSQL(drop_table1);
        onCreate(db);
    }
    public void addQuestion(Question question){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("question", question.getQuestion());
        values.put("a", question.getA());
        values.put("b", question.getB());
        values.put("c", question.getC());
        values.put("d", question.getD());
        values.put("answer", question.getAnswer());
        sqLiteDatabase.insert(table_name, null, values);
    }
    public void updateQuestion(Question question) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("question", question.getQuestion());
        values.put("a", question.getA());
        values.put("b", question.getB());
        values.put("c", question.getC());
        values.put("d", question.getD());
        values.put("answer", question.getAnswer());
        sqLiteDatabase.update(table_name, values, Question._ID + "=?",new String []{question.getQuestion(), question.getA(), question.getA(), question.getB(), question.getC(), question.getD(), question.getAnswer()});
    }
    public void deleteQuestion(Question question) {
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        sqLiteDatabase.delete(table_name, Question._ID +"=?",new String []{question.getQuestion(), question.getA(), question.getA(), question.getB(), question.getC(), question.getD(), question.getAnswer()});
    }
    public ArrayList<Question> getAllQuestion(Question question) {
        ArrayList<Question> data = new ArrayList<>();
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from "+table_name, null);
        cursor.moveToFirst();
        while(cursor.isAfterLast() == false){
            data.add(new Question(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6)));
            cursor.moveToNext();
        }
        return data;
    }
    public Question getQuestionById(int id){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from "+ table_name + " where " + Question._ID + " = " + id, null);
        if(cursor.moveToNext()){
            Question s=new Question(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6));
            return s;
        }
        return null;
    }
    public Question getQuestionByIdListen(int id){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from "+ table_name1 + " where " + Question._ID + " = " + id, null);
        if(cursor.moveToNext()){
            Question s=new Question(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), cursor.getString(6));
            return s;
        }
        return null;
    }
}
