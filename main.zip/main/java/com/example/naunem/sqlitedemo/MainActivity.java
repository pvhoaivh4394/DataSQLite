package com.example.naunem.sqlitedemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DataSQLite dataSQLite = new DataSQLite(this);
        Question question1 = new Question("dfdf", "fdffd", "dfdf", "dfdf", "dfdf", "dfdf");
        Question question2 = new Question("dfdf", "nhan", "dfdf", "dfdf", "dfdf", "dfdf");
        Question question3 = new Question("dfdf", "fdffd", "dfdf", "dfdf", "dfdf", "dfdf");
        Question question4 = new Question("dfdf", "fdffd", "dfdf", "dfdf", "dfdf", "dfdf");
        Question question5 = new Question("dfdf", "fdffd", "dfdf", "dfdf", "dfdf", "dfdf");
        dataSQLite.addQuestion(question1);
        dataSQLite.addQuestion(question2);
        dataSQLite.addQuestion(question3);
        dataSQLite.addQuestion(question4);
        dataSQLite.addQuestion(question5);

        for (int i = 0; i < 5; i++) {
            System.out.println("nhan"+ dataSQLite.getQuestionById(2).getQuestion());
        }
    }
}
